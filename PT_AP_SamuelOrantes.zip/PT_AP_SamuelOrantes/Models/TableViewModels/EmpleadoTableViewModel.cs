﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PT_AP_SamuelOrantes.Models.TableViewModels
{
    public class EmpleadoTableViewModel
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string DPI { get; set; }
        public decimal? BonoDecreto { get; set; }
        public DateTime? fechaCreacion { get; set; }
        public DateTime? fechaModificacion { get; set; }
        public decimal? IGSS { get; set; }
        public decimal? IRTRA { get; set; }
        public decimal? BonoPaternidad { get; set; }
        public decimal? SalarioTotal { get; set; }
        public decimal? SalarioLiquido { get; set; }

    }
}