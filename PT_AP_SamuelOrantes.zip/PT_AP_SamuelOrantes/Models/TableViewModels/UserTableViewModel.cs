﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PT_AP_SamuelOrantes.Models.TableViewModels
{
    public class UserTableViewModel
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Email { get; set; }
        public DateTime? FecNac { get; set; }
    }
}