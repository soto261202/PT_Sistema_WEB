
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 06/15/2023 21:33:12
-- Generated from EDMX file: C:\.Net\PT_AP_SamuelOrantes\PT_AP_SamuelOrantes\Models\DB.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [PruebaTecnica];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_Empleado_Usuario]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Empleado] DROP CONSTRAINT [FK_Empleado_Usuario];
GO
IF OBJECT_ID(N'[dbo].[FK_Usuario_Estado]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Usuario] DROP CONSTRAINT [FK_Usuario_Estado];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Empleado]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Empleado];
GO
IF OBJECT_ID(N'[dbo].[Estado]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Estado];
GO
IF OBJECT_ID(N'[dbo].[Usuario]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Usuario];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Empleado'
CREATE TABLE [dbo].[Empleado] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [DPI] varchar(15)  NULL,
    [NombreCompleto] varchar(200)  NULL,
    [CantidadHijos] int  NULL,
    [SalarioBase] decimal(18,2)  NULL,
    [BonoDecreto] decimal(18,2)  NULL,
    [IdUsuario] int  NULL,
    [FechaCreación] datetime  NULL,
    [Igss] decimal(18,2)  NULL,
    [Irtra] decimal(18,2)  NULL,
    [BonoPaternidad] decimal(18,2)  NULL,
    [SalarioTotal] decimal(18,2)  NULL,
    [SalarioLiquido] decimal(18,2)  NULL
);
GO

-- Creating table 'Estado'
CREATE TABLE [dbo].[Estado] (
    [id] int IDENTITY(1,1) NOT NULL,
    [Nombre] varchar(100)  NULL
);
GO

-- Creating table 'Usuario'
CREATE TABLE [dbo].[Usuario] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nombre] varchar(200)  NULL,
    [Email] varchar(100)  NULL,
    [FechaNacimiento] datetime  NULL,
    [passw] varchar(200)  NULL,
    [IdEstado] int  NULL,
    [token_recovery] varchar(200)  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Empleado'
ALTER TABLE [dbo].[Empleado]
ADD CONSTRAINT [PK_Empleado]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [id] in table 'Estado'
ALTER TABLE [dbo].[Estado]
ADD CONSTRAINT [PK_Estado]
    PRIMARY KEY CLUSTERED ([id] ASC);
GO

-- Creating primary key on [Id] in table 'Usuario'
ALTER TABLE [dbo].[Usuario]
ADD CONSTRAINT [PK_Usuario]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [IdUsuario] in table 'Empleado'
ALTER TABLE [dbo].[Empleado]
ADD CONSTRAINT [FK_Empleado_Usuario]
    FOREIGN KEY ([IdUsuario])
    REFERENCES [dbo].[Usuario]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Empleado_Usuario'
CREATE INDEX [IX_FK_Empleado_Usuario]
ON [dbo].[Empleado]
    ([IdUsuario]);
GO

-- Creating foreign key on [IdEstado] in table 'Usuario'
ALTER TABLE [dbo].[Usuario]
ADD CONSTRAINT [FK_Usuario_Estado]
    FOREIGN KEY ([IdEstado])
    REFERENCES [dbo].[Estado]
        ([id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Usuario_Estado'
CREATE INDEX [IX_FK_Usuario_Estado]
ON [dbo].[Usuario]
    ([IdEstado]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------