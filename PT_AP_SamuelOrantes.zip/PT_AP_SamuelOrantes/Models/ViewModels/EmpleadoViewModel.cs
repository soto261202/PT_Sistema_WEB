﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace PT_AP_SamuelOrantes.Models.ViewModels
{
    public class EmpleadoViewModel
    {
        [Required]
        [StringLength(100, ErrorMessage = "El {0} debe tener al menos {1} caracteres", MinimumLength = 1)]
        [Display(Name = "Nombre Completo")]
        public string NombreCompleto { get; set; }

        [Required]
        [Display(Name = "DPI")]
        public string DPI { get; set; }

        
        [Display(Name = "Cantidad de Hijos")]
        public int CantHijos { get; set; }

        [Display(Name = "Salario Base")]
        public decimal SalarioBase { get; set; }

        [Display(Name = "Bono Decreto")]
        public decimal BonoDecreto { get; set; }

        [Display(Name = "Igss")]
        public decimal Igss { get; set; }

        [Display(Name = "Irtra")]
        public decimal Irtra { get; set; }

        [Display(Name = "Bono Paternidad")]
        public decimal BonoPaternidad { get; set; }

        [Display(Name = "Salario Total")]
        public decimal SalarioTotal { get; set; }

        [Display(Name = "Salario Liquido")]
        public decimal SalarioLiquido { get; set; }

        [Display(Name = "Id Usuaio")]
        public int IdUsuario { get; set; }

        [Display(Name = "Fecha de creación")]
        public DateTime? FecCreat { get; set; }

        [Display(Name = "Fecha de Modificación")]
        public DateTime? FechModi { get; set; }
    }

    public class EditEmpleadoViewModel
    {
        public int Id { get; set; }
        [Required]
        [StringLength(100, ErrorMessage = "El {0} debe tener al menos {1} caracteres", MinimumLength = 1)]
        [Display(Name = "Nombre Cpmpleto")]
        public string NombreCompleto { get; set; }

        [Required]
        [Display(Name = "DPI")]
        public string DPI { get; set; }


        [Display(Name = "Cantidad de Hijos")]
        public int? CantHijos { get; set; }

        [Display(Name = "Salario Base")]
        public decimal? SalarioBase { get; set; }

        [Display(Name = "Bono Decreto")]
        public decimal? BonoDecreto { get; set; }

        [Display(Name = "Igss")]
        public decimal? Igss { get; set; }

        [Display(Name = "Irtra")]
        public decimal? Irtra { get; set; }

        [Display(Name = "Bono Paternidad")]
        public decimal? BonoPaternidad { get; set; }

        [Display(Name = "Salario Total")]
        public decimal? SalarioTotal { get; set; }

        [Display(Name = "Salario Liquido")]
        public decimal? SalarioLiquido { get; set; }

        [Display(Name = "Id Usuaio")]
        public int IdUsuario { get; set; }

        [Display(Name = "Fecha de creación")]
        public DateTime? FecCreat { get; set; }

        [Display(Name = "Fecha de Modificación")]
        public DateTime? FechModi { get; set; }

        
    }

    public class DetailEmpleadoViewModel
    {
        public int Id { get; set; }
        [Required]
        [StringLength(100, ErrorMessage = "El {0} debe tener al menos {1} caracteres", MinimumLength = 1)]
        [Display(Name = "Nombre Cpmpleto")]
        public string NombreCompleto { get; set; }

        [Required]
        [Display(Name = "DPI")]
        public string DPI { get; set; }


        [Display(Name = "Cantidad de Hijos")]
        public int? CantHijos { get; set; }

        [Display(Name = "Salario Base")]
        public decimal? SalarioBase { get; set; }

        [Display(Name = "Bono Decreto")]
        public decimal? BonoDecreto { get; set; }

        [Display(Name = "Igss")]
        public decimal? Igss { get; set; }

        [Display(Name = "Irtra")]
        public decimal? Irtra { get; set; }

        [Display(Name = "Bono Paternidad")]
        public decimal? BonoPaternidad { get; set; }

        [Display(Name = "Salario Total")]
        public decimal? SalarioTotal { get; set; }

        [Display(Name = "Salario Liquido")]
        public decimal? SalarioLiquido { get; set; }

        [Display(Name = "Id Usuaio")]
        public int IdUsuario { get; set; }

        [Display(Name = "Fecha de creación")]
        public DateTime? FechaCreacion { get; set; }

        [Display(Name = "Fecha de Modificación")]
        public DateTime? FechaModificacion { get; set; }
    }
}