﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PT_AP_SamuelOrantes.Models.ViewModels
{
    public class RecoveryPassWordViewModel
    {
        public string token { get; set; }
        [Required]
        public string PassWord { get; set; }

        [Compare("PassWord")]
        [Required]
        public string PassWord2 { get; set; }
    }
}