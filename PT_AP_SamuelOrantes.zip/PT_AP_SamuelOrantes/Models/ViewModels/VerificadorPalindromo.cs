﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace PT_AP_SamuelOrantes.Models.ViewModels
{
    public class VerificadorPalindromo
    {
       
        [Required]
        [StringLength(100, ErrorMessage = "El {0} debe tener al menos {1} caracteres", MinimumLength = 1)]
        [Display(Name = "Varificador")]
        public string Palabra { get; set; }
  

    }
}