﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace PT_AP_SamuelOrantes.Models.ViewModels
{
    public class RecoveryViewModel
    {
        [EmailAddress]
        [Required]
        public string Email { get; set; }

        //[Required]
        //[Display(Name = "Fecha de Nacimiento   YYYY-MM-DD")]
        //public DateTime FechaNac { get; set; }
    }
}