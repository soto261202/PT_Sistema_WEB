﻿using PT_AP_SamuelOrantes.Models;
using PT_AP_SamuelOrantes.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PT_AP_SamuelOrantes.Controllers
{
    public class PolindromosController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        // GET: Polindromos
        public ActionResult VerificarPalindromo()
        {
            return View();
        }

        [HttpPost]
        public ActionResult VerificarPalindromo(VerificadorPalindromo model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            else
            {
                string inverso, caracter;
                int i = model.Palabra.Length;
                inverso = "";

                for (int x = i - 1; x >= 0; x--)
                {
                    caracter = model.Palabra.Substring(x, 1);
                    inverso = inverso + caracter;
                }
                if (model.Palabra == inverso)
                {
                    ViewBag.Message = $"La palabra -> {model.Palabra} <- Es Palíndromo, su inverso es ->{inverso}";
                    return View("EsPalindromo");
                }
                else
                {
                    ViewBag.Message = $"La palabra -> {model.Palabra} <- No es Palíndromo, su inverso es -> {inverso}";
                    return View("EsPalindromo");
                }

            }


        }
    }
}


//using PT_AP_SamuelOrantes.Models;
//using PT_AP_SamuelOrantes.Models.ViewModels;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using System.Web.Mvc;

//namespace PT_AP_SamuelOrantes.Controllers
//{
//    public class PolindromosController : Controller
//    {
//        public ActionResult Index()
//        {
//            return View();
//        }

        //[HttpPost]
        //public ActionResult VerificarPalindromo(VerificadorPalindromo model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return View(model);
        //    }
        //    else
        //    {
        //        int cantidadPalindromos = ContarPalindromos(model.Palabra);
        //        string mensaje = "";
        //        if (cantidadPalindromos > 0)
        //        {
        //            mensaje = "La cantidad de palíndromos encontrados: " + cantidadPalindromos;
        //        }
        //        else
        //        {
        //            mensaje = "No se encontraron palíndromos.";
        //        }
        //        TempData["Mensaje"] = mensaje;
        //        return RedirectToAction("Index");
        //    }
        //}

        //public ActionResult ContarPalindromos(string texto)
        //{
        //    // Lógica para contar los palíndromos en el texto ingresado
        //    List<string> palindromos = new List<string>();
        //    // ...

        //    // Aquí se debe implementar la lógica para contar los palíndromos en el texto
        //    // Puedes usar el código que mencionaste en la pregunta para verificar si una palabra es palíndromo y agregarla a la lista "palindromos"

        //    int cantidadPalindromos = palindromos.Count;
        //    return Json(new { cantidadPalindromos, palindromos }, JsonRequestBehavior.AllowGet);
        //}


        //[HttpPost]
        //public ActionResult VerificarPalindromo(VerificadorPalindromo model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return View(model);
        //    }
        //    else
        //    {
        //        var resultado = ContarPalindromos(model.Palabra);
        //        return Json(resultado);
        //    }
        //}

        //public JsonResult ContarPalindromos(string texto)
        //{
        //    // Lógica para contar los palíndromos en el texto ingresado
        //    List<string> palindromos = new List<string>();
        //    // ...

        //    // Aquí se debe implementar la lógica para contar los palíndromos en el texto
        //    // Puedes usar el código que mencionaste en la pregunta para verificar si una palabra es palíndromo y agregarla a la lista "palindromos"

        //    int cantidadPalindromos = palindromos.Count;
        //    return Json(new { cantidadPalindromos, palindromos }, JsonRequestBehavior.AllowGet);
        //}

//    }
//}
