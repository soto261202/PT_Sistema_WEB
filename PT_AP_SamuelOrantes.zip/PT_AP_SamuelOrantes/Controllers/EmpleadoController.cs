﻿using PT_AP_SamuelOrantes.Models.ViewModels;
using PT_AP_SamuelOrantes.Models.TableViewModels;
using PT_AP_SamuelOrantes.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Core.Metadata.Edm;

namespace PT_AP_SamuelOrantes.Controllers
{
    public class EmpleadoController : Controller
    {
        // GET: Empleado
        public ActionResult Index()
        {
            List<EmpleadoTableViewModel> list = null;
            using (PTecnicaEntities _db = new PTecnicaEntities())
            {
                int tempSession = ((Usuario)Session["Usuario"]).Id;
                list = (from d in _db.Empleado
                        where d.IdUsuario == tempSession
                        orderby d.NombreCompleto
                        select new EmpleadoTableViewModel
                        {
                            Nombre = d.NombreCompleto,
                            DPI = d.DPI,
                            Id = d.Id,
                            SalarioLiquido = d.SalarioLiquido,
                            BonoDecreto= d.BonoDecreto,
                            fechaCreacion = d.FechaCreacion,
                            IGSS = d.Igss,
                            IRTRA = d.Irtra,
                            BonoPaternidad= d.BonoPaternidad,
                            SalarioTotal= d.SalarioTotal

                        }).ToList();
            }

            return View(list);
        }

        [HttpGet]
        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(EmpleadoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            using (var _db = new PTecnicaEntities())
            {
                Empleado oUser = new Empleado();
                //oUser.IdUsuario = 3;
                oUser.NombreCompleto = model.NombreCompleto;
                oUser.DPI = model.DPI;
                oUser.CantidadHijos = model.CantHijos;
                oUser.SalarioBase = model.SalarioBase;
                oUser.BonoDecreto = 250M;
                oUser.FechaCreacion = DateTime.Now;
                oUser.FechaModificacion = DateTime.Now;
                oUser.Igss = oUser.SalarioBase * 0.0483M;
                oUser.Irtra = oUser.SalarioBase * 0.01M;
                oUser.BonoPaternidad = oUser.CantidadHijos * 133M;
                oUser.SalarioTotal = oUser.SalarioBase + oUser.BonoPaternidad + oUser.BonoDecreto;
                oUser.SalarioLiquido = oUser.SalarioTotal - oUser.Igss - oUser.Irtra;

                _db.Empleado.Add(oUser);

                //var tep = _db.Usuario.First(x => x.Id == ((Usuario)Session["Usuario"]).Id);
                oUser.IdUsuario = ((Usuario)Session["Usuario"]).Id;
                _db.Entry(oUser).Reference(c => c.Usuario).Load();
                _db.SaveChanges();
            }
            return Redirect(Url.Content("~/Empleado/"));
        }

        public ActionResult Edit(int Id)
        {
            EditEmpleadoViewModel model = new EditEmpleadoViewModel();

            using (var _db = new PTecnicaEntities())
            {
                var oUser = _db.Empleado.Find(Id);

                model.NombreCompleto = oUser.NombreCompleto;
                model.DPI = oUser.DPI;
                model.CantHijos = oUser.CantidadHijos;
                model.SalarioBase = oUser.SalarioBase;
                model.BonoDecreto = oUser.BonoDecreto;
                model.Igss = oUser.Igss;
                model.Irtra = oUser.Irtra;
                model.BonoPaternidad = oUser.BonoPaternidad;
                model.SalarioTotal = oUser.SalarioTotal;
                model.SalarioLiquido = oUser.SalarioLiquido;
                model.FecCreat = oUser.FechaCreacion;
                model.FecCreat = oUser.FechaModificacion;
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(EditEmpleadoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            using (var _db = new PTecnicaEntities())
            {
                var oUser = _db.Empleado.Find(model.Id);

                oUser.NombreCompleto = model.NombreCompleto;
                oUser.DPI = model.DPI;
                oUser.CantidadHijos = model.CantHijos;
                oUser.SalarioBase = model.SalarioBase;
                oUser.BonoDecreto = 250M;
                oUser.FechaModificacion = DateTime.Now;
                oUser.Igss = oUser.SalarioBase * 0.0483M;
                oUser.Irtra = oUser.SalarioBase * 0.01M;
                oUser.BonoPaternidad = oUser.CantidadHijos * 133M;
                oUser.SalarioTotal = oUser.SalarioBase + oUser.BonoPaternidad + oUser.BonoDecreto;
                oUser.SalarioLiquido = oUser.SalarioTotal - oUser.Igss - oUser.Irtra;

                _db.Entry(oUser).State = System.Data.Entity.EntityState.Modified;
                _db.SaveChanges();
            }

            return Redirect(Url.Content("~/Empleado/"));
        }


        [HttpPost]
        public ActionResult Delete(int Id)
        {
            using (var _db = new PTecnicaEntities())
            {
                Empleado emp = _db.Empleado.Where(x => x.Id == Id).FirstOrDefault();
                _db.Empleado.Remove(emp);
                _db.SaveChanges();
            }
            return Content("1");
        }

        public ActionResult Details(int id)
        {
            DetailEmpleadoViewModel model = new DetailEmpleadoViewModel();

            using (var _db = new PTecnicaEntities())
            {
                var oUser = _db.Empleado.Find(id);

                model.NombreCompleto = oUser.NombreCompleto;
                model.DPI = oUser.DPI;
                model.CantHijos = oUser.CantidadHijos;
                model.SalarioBase = oUser.SalarioBase;
                model.BonoDecreto = oUser.BonoDecreto;
                model.Igss = oUser.Igss;
                model.Irtra = oUser.Irtra;
                model.BonoPaternidad = oUser.BonoPaternidad;
                model.SalarioTotal = oUser.SalarioTotal;
                model.SalarioLiquido = oUser.SalarioLiquido;
                model.FechaCreacion= oUser.FechaCreacion;
                model.FechaModificacion = oUser.FechaModificacion;
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult Details(DetailEmpleadoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            return Redirect(Url.Content("~/Empleado/"));
        }
    }
}