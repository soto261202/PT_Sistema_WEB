﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using PT_AP_SamuelOrantes.Models;

namespace PT_AP_SamuelOrantes.Controllers
{
    public class AccessController : Controller
    {

        string urlDomain = "https://localhost:44384";
        // GET: Access
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Enter(string user, string password)
        {
            try
            {
                using (PTecnicaEntities _db = new PTecnicaEntities())
                {
                    var list = from d in _db.Usuario
                               where d.Email == user && d.passw == password && d.IdEstado == 1
                               select d;

                    if (list.Count() > 0)
                    {
                        Usuario oUsuario = list.First();
                        Session["Usuario"] = oUsuario;
                        return Content("1");
                    }
                    else
                    {
                        return Content("Usuario invalido");
                    }
                }


            }
            catch (Exception ex)
            {
                return Content("Ha ocurrio un error" + ex.Message);
            }

        }

        [HttpGet]
        public ActionResult StartRecovery()
        {
            Models.ViewModels.RecoveryViewModel model = new Models.ViewModels.RecoveryViewModel();
            return View(model);
        }
        [HttpPost]
        public ActionResult StartRecovery(Models.ViewModels.RecoveryViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View(model);
                }

                string token = GetSha256(Guid.NewGuid().ToString());

                using (Models.PTecnicaEntities _db = new Models.PTecnicaEntities())
                {
                    var oUser = _db.Usuario.Where(x => x.Email == model.Email).FirstOrDefault();
                    if (oUser != null)
                    {
                        oUser.token_recovery = token;
                        _db.Entry(oUser).State = System.Data.Entity.EntityState.Modified;
                        _db.SaveChanges();

                        //enviar Mail
                        SendEmail(oUser.Email, token);
                    }
                }

                return View();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [HttpGet]
        public ActionResult Recovery(string token)
        {
            Models.ViewModels.RecoveryPassWordViewModel model = new Models.ViewModels.RecoveryPassWordViewModel();
            model.token = token;
            using (Models.PTecnicaEntities _db = new PTecnicaEntities())
            {
                if (model.token == null || model.token.Trim().Equals(""))
                {
                    return View("Index");
                }
                var oUser = _db.Usuario.Where(x => x.token_recovery == model.token).FirstOrDefault();
                if (oUser == null)
                {
                    ViewBag.Error = "Tu token ha expirado";
                    return View("Index");
                }
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult Recovery(Models.ViewModels.RecoveryPassWordViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View(model);
                }
                using (Models.PTecnicaEntities _db = new Models.PTecnicaEntities())
                {
                    var oUser = _db.Usuario.Where(x => x.token_recovery == model.token).FirstOrDefault();
                    if (oUser != null)
                    {
                        oUser.passw = model.PassWord;
                        oUser.token_recovery = null; //anular el token
                        _db.Entry(oUser).State = System.Data.Entity.EntityState.Modified;
                        _db.SaveChanges();
                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            ViewBag.Message = "Contraseña modificada con exito";
            return View("Index");
        }

        #region Helpers
        private string GetSha256(string str)
        {
            SHA256 sha256 = SHA256Managed.Create();
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] stream = null;
            StringBuilder sb = new StringBuilder();
            stream = sha256.ComputeHash(encoding.GetBytes(str));
            for (int i = 0; i < stream.Length; i++) sb.AppendFormat("{0:x2}", stream[i]);
            return sb.ToString();
        }

        private void SendEmail(string EmailDestino, string token)
        {
            string url = urlDomain + "/Access/Recovery/?token=" + token;

            string fromAddress = "pruebasprogra26@outlook.com";

            string fromPassword = "kjlhutuapbjvctjb";

            string toAddress = EmailDestino;

            string subject = "Password reset for your account";

            string body = "<html>" +

                     "<body>" +

                     "<h1>Cambio de contraseña</h1>" +

                     "<p>Estimado usuario,</p>" +

                     "<p>Hemos recibido una solicitud para restablecer la contraseña de su cuenta.</p>" +

                     "<p>Para continuar con el proceso de restablecimiento de contraseña, haga clic en el siguiente enlace:</p>" +

                     $"<a href={url}> Click para cambiar Contraseña </a>" +

                 "<p>Si no ha solicitado el restablecimiento de contraseña, puede ignorar este correo electrónico.</p>" +

                 "</body>" +

               "</html>";



            // Configuración del cliente SMTP

            var smtpClient = new SmtpClient("smtp-mail.outlook.com")

            {

                Port = 587,

                Credentials = new NetworkCredential(fromAddress, fromPassword),

                EnableSsl = true

            };



            // Creación del correo electrónico

            var email = new MailMessage

            {

                From = new MailAddress(fromAddress),

                Subject = subject,

                Body = body,

                IsBodyHtml = true

            };

            email.To.Add(toAddress);



            // Agregar campo ReplyTo

            email.ReplyToList.Add(new MailAddress(fromAddress));



            // Envío del correo electrónico

            try

            {

                smtpClient.Send(email);

                Console.WriteLine("Correo electrónico enviado exitosamente.");

            }

            catch (Exception ex)

            {

                Console.WriteLine("Error al enviar correo electrónico: " + ex.Message);
            }
        }

        #endregion

    }
}