﻿using PT_AP_SamuelOrantes.Models.TableViewModels;
using PT_AP_SamuelOrantes.Models.ViewModels;
using PT_AP_SamuelOrantes.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PT_AP_SamuelOrantes.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            List<UserTableViewModel> list = null;
            using (PTecnicaEntities _db = new PTecnicaEntities())
            {
                int tempSession = ((Usuario)Session["Usuario"]).Id;
                list = (from d in _db.Usuario
                        where d.Id == tempSession
                        orderby d.Nombre
                        select new UserTableViewModel
                        {
                            Nombre = d.Nombre,
                            Email = d.Email,
                            Id = d.Id,
                            FecNac = d.FechaNacimiento
                        }).ToList();
            }

            return View(list);
        }

        [HttpGet]
        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(UserViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            using (var _db = new PTecnicaEntities())
            {
                Usuario oUser = new Usuario();
                oUser.IdEstado = 1;
                oUser.Nombre = model.Nombre;
                oUser.Email = model.Email;
                oUser.FechaNacimiento = model.FecNac;
                oUser.passw = model.Password;

                _db.Usuario.Add(oUser);
                _db.SaveChanges();
            }
            return Redirect(Url.Content("~/User/"));
        }

        public ActionResult Edit(int Id)
        {
            EditUserViewModel model = new EditUserViewModel();

            using (var _db = new PTecnicaEntities())
            {
                var oUser = _db.Usuario.Find(Id);
                model.FecNac = oUser.FechaNacimiento;
                model.Nombre = oUser.Nombre;
                model.Email = oUser.Email;
                model.Id = oUser.Id;
                model.Estado = oUser.IdEstado;

            }


            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(EditUserViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            using (var _db = new PTecnicaEntities())
            {
                var oUser = _db.Usuario.Find(model.Id);
                oUser.Nombre = model.Nombre;
                oUser.Email = model.Email;
                oUser.FechaNacimiento = model.FecNac;
                oUser.IdEstado = model.Estado;

                if (model.Password != null && model.Password.Trim() != "")
                {
                    oUser.passw = model.Password;
                }

                _db.Entry(oUser).State = System.Data.Entity.EntityState.Modified;
                _db.SaveChanges();

            }


            return Redirect(Url.Content("~/User/"));
        }
    }
}
